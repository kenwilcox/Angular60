What you need to do to make this work - node and npm need to be installed

```
  npm install
```

For POSIX systems (Linux, OS X) the following should work

```
  npm start
```

Windows seemed to barf on that so I opened up two command prompts in the first I typed

```
  npm run tsc:w
```

and the second I ran

```
  npm run lite
```

And everything worked for me.

